package edu.triana.salesianos.culturalia.service;

import edu.triana.salesianos.culturalia.dto.CrearOrganizadorDTO;
import edu.triana.salesianos.culturalia.dto.OrganizadorResponseDTO;
import edu.triana.salesianos.culturalia.error.notFound.OrganizadorNotFoundException;
import edu.triana.salesianos.culturalia.model.Organizador;
import edu.triana.salesianos.culturalia.model.Taller;
import edu.triana.salesianos.culturalia.repository.OrganizadorRepository;
import edu.triana.salesianos.culturalia.repository.TallerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class OrganizadorService {

    private final OrganizadorRepository organizadorRepository;
    private final TallerRepository tallerRepository;

    public OrganizadorResponseDTO save(CrearOrganizadorDTO dto) {
        Organizador nuevo = Organizador.builder()
                .nombre(dto.getNombre())
                .email(dto.getEmail())
                .build();

        Organizador guardado = organizadorRepository.save(nuevo);
        return OrganizadorResponseDTO.of(guardado);
    }

    public List<OrganizadorResponseDTO> findAll() {
        List<Organizador> result = organizadorRepository.findAll();

        if (result.isEmpty()) {
            throw new OrganizadorNotFoundException("No se han encontrado organizadores");
        }

        return result.stream()
                .map(OrganizadorResponseDTO::of)
                .toList();
    }
    public OrganizadorResponseDTO findById(Long id) {
        return organizadorRepository.findById(id)
                .map(OrganizadorResponseDTO::of)
                .orElseThrow(() -> new OrganizadorNotFoundException(id));
    }

    public OrganizadorResponseDTO update(Long id, CrearOrganizadorDTO dto) {
        Organizador organizador = organizadorRepository.findById(id)
                .orElseThrow(() -> new OrganizadorNotFoundException(id));

        organizador.setNombre(dto.getNombre());
        organizador.setEmail(dto.getEmail());

        return OrganizadorResponseDTO.of(organizadorRepository.save(organizador));
    }

    public void deleteById(Long id) {
        Organizador organizador = organizadorRepository.findById(id)
                .orElseThrow(() -> new OrganizadorNotFoundException(id));
        for (Taller taller : organizador.getTalleres()) {
            taller.setOrganizador(null);
        }
        tallerRepository.saveAll(organizador.getTalleres());
        organizadorRepository.delete(organizador);
    }


}
