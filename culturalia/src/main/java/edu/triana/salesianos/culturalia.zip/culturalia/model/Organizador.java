package edu.triana.salesianos.culturalia.model;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Organizador {

    @Id
    @GeneratedValue
    private Long id;
    private String nombre;
    private String email;

    @OneToMany(mappedBy = "organizador")
    @Builder.Default
    private List<Taller> talleres = new ArrayList<>();
}
